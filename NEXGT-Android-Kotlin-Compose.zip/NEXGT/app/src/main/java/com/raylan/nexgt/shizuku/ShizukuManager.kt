package com.raylan.nexgt.shizuku

import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuRemoteProcess
import java.io.BufferedReader
import java.io.InputStreamReader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class ShizukuLogEntry(
    val id: Long,
    val timestamp: String,
    val command: String,
    val success: Boolean,
    val output: String
)

enum class ShizukuConnectionState {
    DISCONNECTED,
    NO_PERMISSION,
    CONNECTED
}

object ShizukuManager {
    private const val REQUEST_CODE_SHIZUKU = 1001

    private val _connectionState = MutableStateFlow(ShizukuConnectionState.DISCONNECTED)
    val connectionState: StateFlow<ShizukuConnectionState> = _connectionState.asStateFlow()

    private val _shizukuUid = MutableStateFlow<Int?>(null)
    val shizukuUid: StateFlow<Int?> = _shizukuUid.asStateFlow()

    private val _shizukuVersion = MutableStateFlow<Int?>(null)
    val shizukuVersion: StateFlow<Int?> = _shizukuVersion.asStateFlow()

    private val _logs = MutableStateFlow<List<ShizukuLogEntry>>(emptyList())
    val logs: StateFlow<List<ShizukuLogEntry>> = _logs.asStateFlow()

    private var initialized = false
    private var logSequence = 0L

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        refreshState()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        _connectionState.value = ShizukuConnectionState.DISCONNECTED
        _shizukuUid.value = null
        appendLog("binderDead", false, "Serviço Shizuku desconectado.")
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == REQUEST_CODE_SHIZUKU) {
                val granted = grantResult == PackageManager.PERMISSION_GRANTED
                refreshState()
                appendLog(
                    "Shizuku.requestPermission($REQUEST_CODE_SHIZUKU)",
                    granted,
                    if (granted) "Permissão Shizuku concedida (Shell UID 2000)." else "Permissão Shizuku negada pelo usuário."
                )
            }
        }

    fun init() {
        if (initialized) {
            refreshState()
            return
        }
        runCatching {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(permissionResultListener)
            initialized = true
            refreshState()
        }.onFailure { err ->
            appendLog("ShizukuManager.init", false, err.message ?: "Erro ao registrar listeners Shizuku.")
        }
    }

    fun dispose() {
        if (!initialized) return
        runCatching {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            Shizuku.removeRequestPermissionResultListener(permissionResultListener)
            initialized = false
        }
    }

    fun refreshState() {
        runCatching {
            val alive = Shizuku.pingBinder()
            if (!alive) {
                _connectionState.value = ShizukuConnectionState.DISCONNECTED
                _shizukuUid.value = null
                _shizukuVersion.value = null
                return
            }
            val granted = Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            _shizukuVersion.value = runCatching { Shizuku.getVersion() }.getOrNull()
            _shizukuUid.value = if (granted) runCatching { Shizuku.getUid() }.getOrNull() else null
            _connectionState.value = if (granted) {
                ShizukuConnectionState.CONNECTED
            } else {
                ShizukuConnectionState.NO_PERMISSION
            }
        }.onFailure {
            _connectionState.value = ShizukuConnectionState.DISCONNECTED
        }
    }

    fun requestAuthorization(): String {
        return runCatching {
            val alive = Shizuku.pingBinder()
            if (!alive) {
                _connectionState.value = ShizukuConnectionState.DISCONNECTED
                appendLog("Shizuku.pingBinder()", false, "Binder inativo. Abra o app Shizuku e inicie o serviço via Depuração Sem Fio ou ADB.")
                return@runCatching "Binder Shizuku inativo. Inicie o serviço no app Shizuku primeiro."
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(REQUEST_CODE_SHIZUKU)
                appendLog("Shizuku.requestPermission($REQUEST_CODE_SHIZUKU)", true, "Solicitação de permissão enviada ao Shizuku.")
                return@runCatching "Solicitando permissão ao Shizuku..."
            } else {
                refreshState()
                appendLog("Shizuku.checkSelfPermission()", true, "Shizuku já conectado e autorizado (UID ${_shizukuUid.value ?: 2000}).")
                return@runCatching "Shizuku já autorizado e pronto."
            }
        }.getOrElse { err ->
            val msg = err.message ?: "Falha ao solicitar autorização Shizuku."
            appendLog("Shizuku.requestAuthorization", false, msg)
            msg
        }
    }

    suspend fun runCommand(cmd: String): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val result = runCatching {
            if (!Shizuku.pingBinder()) {
                return@runCatching false to "Shizuku não está ativo (pingBinder = false)."
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                return@runCatching false to "Permissão Shizuku não concedida."
            }

            // Reflection para compatibilidade total Android 14 / 15 / 16
            val newProcessMethod = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            ).apply {
                isAccessible = true
            }

            val process = newProcessMethod.invoke(
                null,
                arrayOf("sh", "-c", cmd),
                null,
                null
            ) as ShizukuRemoteProcess

            val stdoutBuilder = StringBuilder()
            val stderrBuilder = StringBuilder()

            BufferedReader(InputStreamReader(process.inputStream)).use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    if (stdoutBuilder.isNotEmpty()) stdoutBuilder.append('\n')
                    stdoutBuilder.append(line)
                }
            }

            BufferedReader(InputStreamReader(process.errorStream)).use { reader ->
                var line: String?
                while (reader.readLine().also { line = it } != null) {
                    if (stderrBuilder.isNotEmpty()) stderrBuilder.append('\n')
                    stderrBuilder.append(line)
                }
            }

            val exitCode = process.waitFor()
            runCatching { process.destroy() }

            val combined = buildString {
                if (stdoutBuilder.isNotEmpty()) append(stdoutBuilder)
                if (stderrBuilder.isNotEmpty()) {
                    if (isNotEmpty()) append('\n')
                    append(stderrBuilder)
                }
                if (isEmpty()) {
                    append(if (exitCode == 0) "OK (código 0)" else "Falha (código $exitCode)")
                }
            }

            (exitCode == 0) to combined
        }.getOrElse { err ->
            false to (err.cause?.message ?: err.message ?: "Erro desconhecido ao executar comando.")
        }

        appendLog(cmd, result.first, result.second)
        result
    }

    fun clearLogs() {
        _logs.value = emptyList()
    }

    fun appendLog(command: String, success: Boolean, output: String) {
        val formatter = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        val entry = ShizukuLogEntry(
            id = ++logSequence,
            timestamp = formatter.format(Date()),
            command = command,
            success = success,
            output = output.trim()
        )
        _logs.value = (listOf(entry) + _logs.value).take(200)
    }
}
