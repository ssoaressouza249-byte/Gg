package com.raylan.nexgt.data

enum class NavTab(val label: String) {
    HOME("Início"),
    GAMES("Jogos"),
    FPS_120("120 FPS"),
    TWEAKS("Ajustes"),
    TOOLS("Ferramentas")
}

enum class TweakCategory(val label: String) {
    PERFORMANCE("Desempenho"),
    DISPLAY("Tela e Imagem"),
    SYSTEM("Sistema"),
    SOUND("Som"),
    INTERNET("Internet")
}

enum class QuickProfile(
    val id: String,
    val title: String,
    val subtitle: String,
    val fpsScore: Float,
    val batteryScore: Float,
    val coolnessScore: Float
) {
    EXTREME("extreme", "EXTREMO", "Máximo FPS 120Hz", 1.0f, 0.35f, 0.45f),
    BALANCED("balanced", "EQUILIBRADO", "Estável 90 FPS", 0.78f, 0.72f, 0.75f),
    BATTERY("battery", "BATERIA", "Foco autonomia", 0.50f, 0.96f, 0.92f),
    CUSTOM("custom", "PERSONAL.", "Perfil customizado", 0.88f, 0.65f, 0.68f)
}

data class GameAppItem(
    val packageName: String,
    val name: String,
    val isAdded: Boolean = true,
    val isFrozen: Boolean = false
)

data class HardwareInfo(
    val model: String = "Desconhecido",
    val socOrGpu: String = "ARM64",
    val refreshRateHz: Int = 60,
    val androidVersion: String = "14",
    val totalRamMb: Long = 0L,
    val freeRamMb: Long = 0L
)

data class Fps120Module(
    val id: String,
    val title: String,
    val description: String,
    val commandTemplate: String,
    val resetCommandTemplate: String,
    val enabled: Boolean = false
)

data class TweakItem(
    val id: String,
    val title: String,
    val summary: String,
    val category: TweakCategory,
    val enableCmd: String,
    val disableCmd: String,
    val isFavorite: Boolean = false,
    val enabled: Boolean = false
)

data class SmartEngineFeature(
    val id: String,
    val title: String,
    val description: String,
    val enabled: Boolean = false
)

object NexgtCatalog {
    val defaultGames: List<GameAppItem> = listOf(
        GameAppItem("com.dts.freefireth", "Free Fire", isAdded = true),
        GameAppItem("com.dts.freefiremax", "Free Fire MAX", isAdded = true),
        GameAppItem("com.roblox.client", "Roblox", isAdded = true)
    )

    val smartEngineDefaults: List<SmartEngineFeature> = listOf(
        SmartEngineFeature("auto_detect", "Detecção Automática", "Aplica perfil ao abrir jogo", true),
        SmartEngineFeature("game_only", "Só no Jogo", "Restaura ajustes ao sair", true),
        SmartEngineFeature("ia_void", "IA Void", "Alocação dinâmica de CPU/GPU", false),
        SmartEngineFeature("adaptive_fps", "FPS Adaptativo", "Estabiliza frame-pacing", true),
        SmartEngineFeature("perf_mode", "Modo Desempenho", "Prioridade máxima no GameService", false)
    )

    fun buildFps120Modules(): List<Fps120Module> = listOf(
        Fps120Module(
            id = "fps_game_service",
            title = "1. Destravar FPS via GameService",
            description = "Força modo performance e meta de 120 FPS diretamente no pacote.",
            commandTemplate = "cmd game set --mode performance --fps 120 {pkg} && cmd game mode performance {pkg}",
            resetCommandTemplate = "cmd game reset {pkg}"
        ),
        Fps120Module(
            id = "fps_downscale",
            title = "2. Downscale GPU (0.75x)",
            description = "Alivia carga de pixel shader mantendo nitidez para ganho bruto de FPS.",
            commandTemplate = "cmd game set --mode performance --downscale 0.75 {pkg}",
            resetCommandTemplate = "cmd game set --mode standard --downscale 1.0 {pkg}"
        ),
        Fps120Module(
            id = "fps_thermal",
            title = "3. Bloquear Estrangulamento Térmico",
            description = "Impede queda forçada de clock para 30/45 FPS durante partidas longas.",
            commandTemplate = "cmd thermalservice override-status 0",
            resetCommandTemplate = "cmd thermalservice reset"
        ),
        Fps120Module(
            id = "fps_fixed_perf",
            title = "4. Modo Performance Fixo CPU/GPU",
            description = "Trava frequências em estado de alto desempenho pelo PowerManager.",
            commandTemplate = "cmd power set-fixed-performance-mode-enabled true",
            resetCommandTemplate = "cmd power set-fixed-performance-mode-enabled false"
        ),
        Fps120Module(
            id = "fps_swap_interval",
            title = "5. Remover Trava SwapInterval & Divisor",
            description = "Zera espera de VSync EGL e remove divisor de quadros HWUI.",
            commandTemplate = "setprop debug.egl.swapinterval 0 && setprop debug.hwui.fps_divisor 1",
            resetCommandTemplate = "setprop debug.egl.swapinterval 1 && setprop debug.hwui.fps_divisor 0"
        ),
        Fps120Module(
            id = "fps_aot_compile",
            title = "6. Compilação Nativa Total (AOT)",
            description = "Compila bytecode completo do jogo em código nativo para zerar engasgos.",
            commandTemplate = "cmd package compile -m everything -f {pkg}",
            resetCommandTemplate = "cmd package compile -m speed-profile {pkg}"
        ),
        Fps120Module(
            id = "fps_refresh_120",
            title = "7. Sincronizar Tela em 120Hz",
            description = "Trava taxa mínima e máxima de atualização do display em 120.0 Hz.",
            commandTemplate = "settings put system peak_refresh_rate 120.0 && settings put system min_refresh_rate 120.0",
            resetCommandTemplate = "settings delete system min_refresh_rate && settings put system peak_refresh_rate 60.0"
        ),
        Fps120Module(
            id = "fps_surfaceflinger",
            title = "8. Desativar Backpressure SurfaceFlinger",
            description = "Reduz fila de composição de quadros e elimina atraso de renderização.",
            commandTemplate = "setprop debug.sf.disable_backpressure 1",
            resetCommandTemplate = "setprop debug.sf.disable_backpressure 0"
        )
    )

    // 64 funções reais organizadas nas 5 sub-abas
    fun build64Tweaks(targetPkg: String = "com.dts.freefireth"): List<TweakItem> = listOf(
        // === DESEMPENHO (16) ===
        TweakItem("perf_01", "Guarda Térmica Zero", "Desativa redução térmica via thermalservice", TweakCategory.PERFORMANCE, "cmd thermalservice override-status 0", "cmd thermalservice reset", isFavorite = true),
        TweakItem("perf_02", "Bloquear Economia de Energia", "Desliga modo economia global", TweakCategory.PERFORMANCE, "settings put global low_power 0", "settings put global low_power 1", isFavorite = true),
        TweakItem("perf_03", "Anti-Travadas AOT", "Compila pacote alvo em modo everything", TweakCategory.PERFORMANCE, "cmd package compile -m everything -f $targetPkg", "cmd package compile -m speed-profile $targetPkg", isFavorite = true),
        TweakItem("perf_04", "Espremer RAM (Trim)", "Libera caches ociosos de apps", TweakCategory.PERFORMANCE, "pm trim-caches 999G", "echo cache_normal", isFavorite = true),
        TweakItem("perf_05", "Compactar Memória", "Força compactação ZRAM/Lmkd", TweakCategory.PERFORMANCE, "am kill-all", "echo ok"),
        TweakItem("perf_06", "Modo Performance Fixo", "Ativa clocks fixos no PowerService", TweakCategory.PERFORMANCE, "cmd power set-fixed-performance-mode-enabled true", "cmd power set-fixed-performance-mode-enabled false"),
        TweakItem("perf_07", "Renderizador SkiaGL", "Usa pipeline OpenGL no HWUI", TweakCategory.PERFORMANCE, "setprop debug.hwui.renderer skiagl", "setprop debug.hwui.renderer skiavk"),
        TweakItem("perf_08", "SwapInterval Zero", "Remove bloqueio VSync EGL", TweakCategory.PERFORMANCE, "setprop debug.egl.swapinterval 0", "setprop debug.egl.swapinterval 1"),
        TweakItem("perf_09", "Forçar MSAA Desligado", "Remove antialiasing pesado", TweakCategory.PERFORMANCE, "setprop debug.egl.force_msaa 0", "setprop debug.egl.force_msaa 1"),
        TweakItem("perf_10", "CPU Boost Touch", "Prioridade ao toque no compositor", TweakCategory.PERFORMANCE, "setprop debug.sf.latch_unsignaled 1", "setprop debug.sf.latch_unsignaled 0"),
        TweakItem("perf_11", "GameMode Performance", "Define GameManager para performance", TweakCategory.PERFORMANCE, "cmd game mode performance $targetPkg", "cmd game mode standard $targetPkg"),
        TweakItem("perf_12", "Desativar Backpressure", "Menos atraso no SurfaceFlinger", TweakCategory.PERFORMANCE, "setprop debug.sf.disable_backpressure 1", "setprop debug.sf.disable_backpressure 0"),
        TweakItem("perf_13", "Sem Limite Processos", "Evita swap excessivo em segundo plano", TweakCategory.PERFORMANCE, "device_config put activity_manager max_cached_processes 32", "device_config delete activity_manager max_cached_processes"),
        TweakItem("perf_14", "Cache Shader GPU", "Maximiza cache de shaders EGL", TweakCategory.PERFORMANCE, "setprop ro.hwui.texture_cache_size 72", "setprop ro.hwui.texture_cache_size 48"),
        TweakItem("perf_15", "Desativar Profiler", "Remove coleta de perfil ART em jogo", TweakCategory.PERFORMANCE, "setprop dalvik.vm.dex2oat-filter speed", "setprop dalvik.vm.dex2oat-filter speed-profile"),
        TweakItem("perf_16", "Prioridade I/O Jogo", "Reduz latência de leitura de assets", TweakCategory.PERFORMANCE, "cmd shortcut reset-all-throttling", "echo ok"),

        // === TELA E IMAGEM (14) ===
        TweakItem("disp_01", "Taxa Máxima 120Hz", "Define peak_refresh_rate em 120.0", TweakCategory.DISPLAY, "settings put system peak_refresh_rate 120.0", "settings put system peak_refresh_rate 60.0"),
        TweakItem("disp_02", "Taxa Mínima 120Hz", "Trava min_refresh_rate em 120.0", TweakCategory.DISPLAY, "settings put system min_refresh_rate 120.0", "settings delete system min_refresh_rate"),
        TweakItem("disp_03", "Escala Janela 0.5x", "Animações de janela ultrarrápidas", TweakCategory.DISPLAY, "settings put global window_animation_scale 0.5", "settings put global window_animation_scale 1.0"),
        TweakItem("disp_04", "Escala Transição 0.5x", "Transições entre telas mais rápidas", TweakCategory.DISPLAY, "settings put global transition_animation_scale 0.5", "settings put global transition_animation_scale 1.0"),
        TweakItem("disp_05", "Duração Animator 0.5x", "Acelera animações do sistema", TweakCategory.DISPLAY, "settings put global animator_duration_scale 0.5", "settings put global animator_duration_scale 1.0"),
        TweakItem("disp_06", "Desativar Blur Janela", "Remove desfoque translúcido da UI", TweakCategory.DISPLAY, "settings put global disable_window_blurs 1", "settings put global disable_window_blurs 0"),
        TweakItem("disp_07", "Brilho Manual Fixo", "Impede oscilações de brilho em jogo", TweakCategory.DISPLAY, "settings put system screen_brightness_mode 0", "settings put system screen_brightness_mode 1"),
        TweakItem("disp_08", "Contador Nativo SF FPS", "Exibe FPS do SurfaceFlinger", TweakCategory.DISPLAY, "setprop debug.sf.showfps 1", "setprop debug.sf.showfps 0"),
        TweakItem("disp_09", "Overdraw GPU Desligado", "Garante zero depuração extra de overdraw", TweakCategory.DISPLAY, "setprop debug.hwui.overdraw false", "setprop debug.hwui.overdraw false"),
        TweakItem("disp_10", "Tempo Tela 10 Min", "Evita apagar tela durante partidas", TweakCategory.DISPLAY, "settings put system screen_off_timeout 600000", "settings put system screen_off_timeout 60000"),
        TweakItem("disp_11", "Modo Cor Saturado", "Realça contraste em mapas escuros", TweakCategory.DISPLAY, "settings put system display_color_mode 2", "settings put system display_color_mode 0"),
        TweakItem("disp_12", "Resposta Toque Rápida", "Reduz atraso de toque longo", TweakCategory.DISPLAY, "settings put secure long_press_timeout 250", "settings put secure long_press_timeout 400"),
        TweakItem("disp_13", "Ponteiro Preciso", "Melhora rastreio de toque contínuo", TweakCategory.DISPLAY, "settings put system pointer_speed 4", "settings put system pointer_speed 0"),
        TweakItem("disp_14", "Downscale 0.8x Nitidez", "Equilíbrio entre nitidez e FPS", TweakCategory.DISPLAY, "cmd game set --mode performance --downscale 0.8 $targetPkg", "cmd game set --mode standard --downscale 1.0 $targetPkg"),

        // === SISTEMA (14) ===
        TweakItem("sys_01", "Congelar 2º Plano", "Restringe execução oculta via appops", TweakCategory.SYSTEM, "appops set $targetPkg RUN_IN_BACKGROUND allow", "appops set $targetPkg RUN_IN_BACKGROUND default"),
        TweakItem("sys_02", "Modo Doze Forçado", "Suspende serviços em idle", TweakCategory.SYSTEM, "dumpsys deviceidle force-idle", "dumpsys deviceidle unforce"),
        TweakItem("sys_03", "Limpar Caches Gerais", "Remove caches temporários de sistema", TweakCategory.SYSTEM, "pm trim-caches 999G", "echo ok"),
        TweakItem("sys_04", "Não Manter Atividades", "Libera telas antigas da memória", TweakCategory.SYSTEM, "settings put global always_finish_activities 0", "settings put global always_finish_activities 0"),
        TweakItem("sys_05", "Sem Logcat Pesado", "Reduz escrita de logs em disco", TweakCategory.SYSTEM, "logcat -G 64K", "logcat -G 256K"),
        TweakItem("sys_06", "Desativar Backup Nuvem", "Evita upload automático em partida", TweakCategory.SYSTEM, "bmgr enable false", "bmgr enable true"),
        TweakItem("sys_07", "Economia Adaptativa Off", "Impede Android de limitar CPU", TweakCategory.SYSTEM, "settings put global adaptive_battery_management_enabled 0", "settings put global adaptive_battery_management_enabled 1"),
        TweakItem("sys_08", "Notificações Heads-Up Off", "Bloqueia banners sobre o jogo", TweakCategory.SYSTEM, "settings put global heads_up_notifications_enabled 0", "settings put global heads_up_notifications_enabled 1"),
        TweakItem("sys_09", "Vibrar ao Tocar Off", "Economiza ciclos e bateria no toque", TweakCategory.SYSTEM, "settings put system haptic_feedback_enabled 0", "settings put system haptic_feedback_enabled 1"),
        TweakItem("sys_10", "Verificador ADB Off", "Acelera abertura e instalação", TweakCategory.SYSTEM, "settings put global verifier_verify_adb_installs 0", "settings put global verifier_verify_adb_installs 1"),
        TweakItem("sys_11", "Stats de Uso Leve", "Reduz polling de estatísticas", TweakCategory.SYSTEM, "cmd usagestats clear-last-used-timestamps $targetPkg", "echo ok"),
        TweakItem("sys_12", "Reset Limite Jobs", "Libera fila de jobs presos", TweakCategory.SYSTEM, "cmd jobscheduler reset-execution-quota -u 0 $targetPkg", "echo ok"),
        TweakItem("sys_13", "Permissão Storage Rápida", "Mantém acesso rápido ao OBB", TweakCategory.SYSTEM, "appops set $targetPkg LEGACY_STORAGE allow", "appops set $targetPkg LEGACY_STORAGE default"),
        TweakItem("sys_14", "Modo Jogo Ativo", "Informa estado GAME_ACTIVE ao sistema", TweakCategory.SYSTEM, "cmd game set --mode performance $targetPkg", "cmd game reset $targetPkg"),

        // === SOM (10) ===
        TweakItem("snd_01", "Baixa Latência Áudio", "Prioriza buffer de áudio para passos", TweakCategory.SOUND, "setprop audio.deep_buffer.media false", "setprop audio.deep_buffer.media true"),
        TweakItem("snd_02", "Desativar Som Teclado", "Remove cliques desnecessários", TweakCategory.SOUND, "settings put system sound_effects_enabled 0", "settings put system sound_effects_enabled 1"),
        TweakItem("snd_03", "Desativar Som Bloqueio", "Silencia trava de tela", TweakCategory.SOUND, "settings put system lockscreen_sounds_enabled 0", "settings put system lockscreen_sounds_enabled 1"),
        TweakItem("snd_04", "Áudio Bluetooth HD", "Prioriza estabilidade A2DP sem atraso", TweakCategory.SOUND, "settings put global bluetooth_a2dp_supports_optional_codecs_enabled 1", "settings put global bluetooth_a2dp_supports_optional_codecs_enabled 0"),
        TweakItem("snd_05", "Modo Mono Off (Estéreo)", "Garante separação esquerda/direita", TweakCategory.SOUND, "settings put system master_mono 0", "settings put system master_mono 0"),
        TweakItem("snd_06", "Balanço Centralizado", "Mantém áudio 50/50 nos fones", TweakCategory.SOUND, "settings put system master_balance 0.0", "settings put system master_balance 0.0"),
        TweakItem("snd_07", "Sem Limite Volume Seguro", "Evita redução súbita em fones", TweakCategory.SOUND, "settings put global audio_safe_volume_state 2", "settings put global audio_safe_volume_state 3"),
        TweakItem("snd_08", "Offload PCM Direto", "Reduz processamento extra na DSP", TweakCategory.SOUND, "setprop audio.offload.disable 1", "setprop audio.offload.disable 0"),
        TweakItem("snd_09", "Microfone Prioritário", "Estabiliza captura de voz em squad", TweakCategory.SOUND, "appops set $targetPkg RECORD_AUDIO allow", "appops set $targetPkg RECORD_AUDIO default"),
        TweakItem("snd_10", "Silenciar Toque Chamada", "Evita cortes de áudio durante jogo", TweakCategory.SOUND, "settings put global zen_mode 1", "settings put global zen_mode 0"),

        // === INTERNET (10) ===
        TweakItem("net_01", "DNS Privado Cloudflare", "Configura 1dot1dot1dot1.cloudflare-dns.com", TweakCategory.INTERNET, "settings put global private_dns_mode hostname && settings put global private_dns_specifier 1dot1dot1dot1.cloudflare-dns.com", "settings put global private_dns_mode off"),
        TweakItem("net_02", "DNS Google Baixo Ping", "Define dns.google para rotas rápidas", TweakCategory.INTERNET, "settings put global private_dns_mode hostname && settings put global private_dns_specifier dns.google", "settings put global private_dns_mode off"),
        TweakItem("net_03", "Wi-Fi Scan Throttling Off", "Estabiliza latência sem buscas extras", TweakCategory.INTERNET, "settings put global wifi_scan_throttle_enabled 1", "settings put global wifi_scan_throttle_enabled 0"),
        TweakItem("net_04", "Sempre Wi-Fi Ativo", "Mantém placa Wi-Fi em modo ativo", TweakCategory.INTERNET, "settings put global wifi_sleep_policy 2", "settings put global wifi_sleep_policy 0"),
        TweakItem("net_05", "Dados em 2º Plano Leve", "Ativa economia para apps paralelos", TweakCategory.INTERNET, "cmd netpolicy set restrict-background true", "cmd netpolicy set restrict-background false"),
        TweakItem("net_06", "Wakeup Wi-Fi Otimizado", "Reduz jitter de pacotes UDP", TweakCategory.INTERNET, "settings put global wifi_wakeup_enabled 0", "settings put global wifi_wakeup_enabled 1"),
        TweakItem("net_07", "TCP Congestion Cubic", "Ajuste de estabilidade de pacotes", TweakCategory.INTERNET, "settings put global tcp_default_init_rwnd 60", "settings delete global tcp_default_init_rwnd"),
        TweakItem("net_08", "Sem Verificação Captive", "Menos pings automáticos de sistema", TweakCategory.INTERNET, "settings put global captive_portal_mode 0", "settings put global captive_portal_mode 1"),
        TweakItem("net_09", "Liberar Sockets Ociosos", "Limpa conexões zumbis no netd", TweakCategory.INTERNET, "cmd connectivity clear-dns-cache", "echo ok"),
        TweakItem("net_10", "Modo Baixa Latência Wi-Fi", "Força Wi-Fi Low Latency Lock", TweakCategory.INTERNET, "cmd wifi set-wifi-enabled enabled", "echo ok")
    )
}
