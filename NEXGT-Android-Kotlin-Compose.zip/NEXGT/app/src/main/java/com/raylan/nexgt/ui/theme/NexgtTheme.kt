package com.raylan.nexgt.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

@Immutable
data class NexgtColorTheme(
    val id: String,
    val name: String,
    val accent: Color,
    val accentHex: String
)

object NexgtThemes {
    val all: List<NexgtColorTheme> = listOf(
        NexgtColorTheme("eclipse", "Roxo Eclipse", Color(0xFFA855F7), "#A855F7"),
        NexgtColorTheme("crimson", "Vermelho Carmesim", Color(0xFFE11D48), "#E11D48"),
        NexgtColorTheme("lightning", "Azul Relâmpago", Color(0xFF3B82F6), "#3B82F6"),
        NexgtColorTheme("venom", "Verde Veneno", Color(0xFF10B981), "#10B981"),
        NexgtColorTheme("mythic", "Ouro Mítico", Color(0xFFF59E0B), "#F59E0B"),
        NexgtColorTheme("cyan", "Ciano Neon", Color(0xFF06B6D4), "#06B6D4"),
        NexgtColorTheme("pink", "Rosa Neon", Color(0xFFEC4899), "#EC4899"),
        NexgtColorTheme("lava", "Laranja Lava", Color(0xFFF97316), "#F97316"),
        NexgtColorTheme("acid", "Lima Ácido", Color(0xFF84CC16), "#84CC16"),
        NexgtColorTheme("abyssal", "Índigo Abyssal", Color(0xFF6366F1), "#6366F1")
    )
}

@Immutable
data class NexgtPalette(
    val oledBackground: Color = Color(0xFF0A0A0C),
    val cardSurface: Color = Color(0xCC13131A),
    val cardSurfaceSolid: Color = Color(0xFF14141B),
    val accent: Color = Color(0xFFA855F7),
    val accentSoft: Color = Color(0x2EA855F7),
    val accentBorder: Color = Color(0x88A855F7),
    val textPrimary: Color = Color(0xFFF4F4F6),
    val textSecondary: Color = Color(0xFFA1A1AA),
    val success: Color = Color(0xFF10B981),
    val danger: Color = Color(0xFFEF4444)
)

val LocalNexgtPalette = staticCompositionLocalOf { NexgtPalette() }

private val NexgtTypography = Typography(
    headlineLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.ExtraBold,
        fontSize = 28.sp
    ),
    titleLarge = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp
    ),
    titleMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = FontFamily.Default,
        fontWeight = FontWeight.Normal,
        fontSize = 13.sp
    ),
    labelMedium = TextStyle(
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp
    )
)

@Composable
fun NexgtTheme(
    selectedTheme: NexgtColorTheme = NexgtThemes.all.first(),
    content: @Composable () -> Unit
) {
    val accent = selectedTheme.accent
    val palette = NexgtPalette(
        accent = accent,
        accentSoft = accent.copy(alpha = 0.16f),
        accentBorder = accent.copy(alpha = 0.55f)
    )

    val colorScheme = darkColorScheme(
        primary = accent,
        secondary = accent,
        background = palette.oledBackground,
        surface = palette.cardSurfaceSolid,
        onPrimary = Color.White,
        onBackground = palette.textPrimary,
        onSurface = palette.textPrimary
    )

    CompositionLocalProvider(LocalNexgtPalette provides palette) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = NexgtTypography,
            content = content
        )
    }
}
