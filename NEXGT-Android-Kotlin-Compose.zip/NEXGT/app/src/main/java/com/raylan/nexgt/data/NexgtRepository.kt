package com.raylan.nexgt.data

import android.app.ActivityManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.view.WindowManager
import java.io.RandomAccessFile

class NexgtRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("nexgt_prefs", Context.MODE_PRIVATE)

    fun getSelectedThemeId(): String = prefs.getString("theme_id", "eclipse") ?: "eclipse"

    fun saveSelectedThemeId(id: String) {
        prefs.edit().putString("theme_id", id).apply()
    }

    fun isBankModeEnabled(): Boolean = prefs.getBoolean("bank_mode", false)

    fun setBankModeEnabled(enabled: Boolean) {
        prefs.edit().putBoolean("bank_mode", enabled).apply()
    }

    fun readHardwareInfo(): HardwareInfo {
        val model = runCatching {
            val mfg = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
            if (Build.MODEL.startsWith(mfg, ignoreCase = true)) Build.MODEL else "$mfg ${Build.MODEL}"
        }.getOrDefault("Android Device")

        val soc = runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val socModel = Build.SOC_MODEL
                if (!socModel.isNullOrBlank() && socModel != "unknown") socModel else Build.HARDWARE
            } else {
                Build.HARDWARE
            }
        }.getOrDefault("ARM64 SoC")

        val refreshHz = runCatching {
            val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            @Suppress("DEPRECATION")
            val display = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                context.display ?: wm.defaultDisplay
            } else {
                wm.defaultDisplay
            }
            display?.mode?.refreshRate?.toInt() ?: 60
        }.getOrDefault(60)

        val memPair = runCatching {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            am.getMemoryInfo(memInfo)
            val totalMb = (memInfo.totalMem / (1024L * 1024L)).coerceAtLeast(readProcMemTotalMb())
            val freeMb = memInfo.availMem / (1024L * 1024L)
            totalMb to freeMb
        }.getOrDefault(0L to 0L)

        return HardwareInfo(
            model = model,
            socOrGpu = soc,
            refreshRateHz = refreshHz,
            androidVersion = Build.VERSION.RELEASE ?: "14",
            totalRamMb = memPair.first,
            freeRamMb = memPair.second
        )
    }

    private fun readProcMemTotalMb(): Long {
        return runCatching {
            RandomAccessFile("/proc/meminfo", "r").use { raf ->
                val line = raf.readLine() ?: return@use 0L
                val kb = line.replace(Regex("[^0-9]"), "").toLongOrNull() ?: 0L
                kb / 1024L
            }
        }.getOrDefault(0L)
    }

    fun getInstalledApps(): List<GameAppItem> {
        return runCatching {
            val pm = context.packageManager
            val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            apps.filter { app ->
                app.packageName != context.packageName &&
                    (app.flags and ApplicationInfo.FLAG_SYSTEM) == 0
            }.map { app ->
                val label = runCatching { pm.getApplicationLabel(app).toString() }.getOrDefault(app.packageName)
                GameAppItem(
                    packageName = app.packageName,
                    name = label,
                    isAdded = false,
                    isFrozen = !app.enabled
                )
            }.sortedBy { it.name.lowercase() }
        }.getOrElse { emptyList() }
    }
}
