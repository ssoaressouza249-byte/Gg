package com.raylan.nexgt.data

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.raylan.nexgt.overlay.FloatingOverlayService
import com.raylan.nexgt.shizuku.ShizukuConnectionState
import com.raylan.nexgt.shizuku.ShizukuLogEntry
import com.raylan.nexgt.shizuku.ShizukuManager
import com.raylan.nexgt.ui.theme.NexgtColorTheme
import com.raylan.nexgt.ui.theme.NexgtThemes
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class NexgtViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = NexgtRepository(application)

    private val _selectedTheme = MutableStateFlow(
        NexgtThemes.all.find { it.id == repo.getSelectedThemeId() } ?: NexgtThemes.all.first()
    )
    val selectedTheme: StateFlow<NexgtColorTheme> = _selectedTheme.asStateFlow()

    private val _hardwareInfo = MutableStateFlow(repo.readHardwareInfo())
    val hardwareInfo: StateFlow<HardwareInfo> = _hardwareInfo.asStateFlow()

    private val _activeProfile = MutableStateFlow(QuickProfile.BALANCED)
    val activeProfile: StateFlow<QuickProfile> = _activeProfile.asStateFlow()

    private val _turboActive = MutableStateFlow(false)
    val turboActive: StateFlow<Boolean> = _turboActive.asStateFlow()

    private val _games = MutableStateFlow(NexgtCatalog.defaultGames)
    val games: StateFlow<List<GameAppItem>> = _games.asStateFlow()

    private val _installedApps = MutableStateFlow<List<GameAppItem>>(emptyList())
    val installedApps: StateFlow<List<GameAppItem>> = _installedApps.asStateFlow()

    private val _targetGamePackage = MutableStateFlow(NexgtCatalog.defaultGames.first().packageName)
    val targetGamePackage: StateFlow<String> = _targetGamePackage.asStateFlow()

    private val _renderScale = MutableStateFlow(100)
    val renderScale: StateFlow<Int> = _renderScale.asStateFlow()

    private val _smartEngine = MutableStateFlow(NexgtCatalog.smartEngineDefaults)
    val smartEngine: StateFlow<List<SmartEngineFeature>> = _smartEngine.asStateFlow()

    private val _fps120Modules = MutableStateFlow(NexgtCatalog.buildFps120Modules())
    val fps120Modules: StateFlow<List<Fps120Module>> = _fps120Modules.asStateFlow()

    private val _tweaks = MutableStateFlow(NexgtCatalog.build64Tweaks())
    val tweaks: StateFlow<List<TweakItem>> = _tweaks.asStateFlow()

    private val _fpsOverlayActive = MutableStateFlow(false)
    val fpsOverlayActive: StateFlow<Boolean> = _fpsOverlayActive.asStateFlow()

    private val _nativeShowFps = MutableStateFlow(false)
    val nativeShowFps: StateFlow<Boolean> = _nativeShowFps.asStateFlow()

    private val _floatingPanelActive = MutableStateFlow(false)
    val floatingPanelActive: StateFlow<Boolean> = _floatingPanelActive.asStateFlow()

    private val _bankMode = MutableStateFlow(repo.isBankModeEnabled())
    val bankMode: StateFlow<Boolean> = _bankMode.asStateFlow()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    val shizukuState: StateFlow<ShizukuConnectionState> = ShizukuManager.connectionState
    val shizukuUid: StateFlow<Int?> = ShizukuManager.shizukuUid
    val shizukuVersion: StateFlow<Int?> = ShizukuManager.shizukuVersion
    val logs: StateFlow<List<ShizukuLogEntry>> = ShizukuManager.logs

    val activeFunctionCount: StateFlow<Int> = combine(
        _tweaks,
        _fps120Modules,
        _smartEngine,
        _turboActive
    ) { tweaksList, fpsList, smartList, turbo ->
        tweaksList.count { it.enabled } +
            fpsList.count { it.enabled } +
            smartList.count { it.enabled } +
            if (turbo) 1 else 0
    }.stateIn(viewModelScope, SharingStarted.Eagerly, 3)

    init {
        ShizukuManager.init()
        refreshInstalledApps()
    }

    fun refreshHardware() {
        _hardwareInfo.value = repo.readHardwareInfo()
    }

    fun refreshInstalledApps() {
        viewModelScope.launch {
            val apps = repo.getInstalledApps()
            if (apps.isNotEmpty()) {
                _installedApps.value = apps
            }
        }
    }

    fun connectShizuku() {
        val msg = ShizukuManager.requestAuthorization()
        _statusBanner.value = msg
    }

    fun selectTheme(theme: NexgtColorTheme) {
        _selectedTheme.value = theme
        repo.saveSelectedThemeId(theme.id)
        if (_floatingPanelActive.value || _fpsOverlayActive.value) {
            syncOverlayService()
        }
    }

    fun clearBanner() {
        _statusBanner.value = null
    }

    fun selectProfile(profile: QuickProfile) {
        _activeProfile.value = profile
        viewModelScope.launch {
            when (profile) {
                QuickProfile.EXTREME -> {
                    ShizukuManager.runCommand("cmd thermalservice override-status 0 && cmd power set-fixed-performance-mode-enabled true")
                }
                QuickProfile.BALANCED -> {
                    ShizukuManager.runCommand("cmd thermalservice reset && cmd power set-fixed-performance-mode-enabled false && cmd game set --mode standard --fps 90 ${_targetGamePackage.value}")
                }
                QuickProfile.BATTERY -> {
                    ShizukuManager.runCommand("cmd power set-fixed-performance-mode-enabled false && settings put global low_power 1")
                }
                QuickProfile.CUSTOM -> {
                    ShizukuManager.appendLog("profile_custom", true, "Perfil personalizado selecionado.")
                }
            }
        }
    }

    fun toggleMasterTurbo() {
        val next = !_turboActive.value
        _turboActive.value = next
        viewModelScope.launch {
            if (next) {
                val pkg = _targetGamePackage.value
                ShizukuManager.runCommand("cmd game mode performance $pkg && pm trim-caches 999G && cmd thermalservice override-status 0")
                _statusBanner.value = "Turbina Jogos ativada para $pkg"
            } else {
                ShizukuManager.runCommand("cmd thermalservice reset && cmd power set-fixed-performance-mode-enabled false")
                _statusBanner.value = "Turbina Jogos desativada"
            }
        }
    }

    fun selectTargetGame(pkg: String) {
        _targetGamePackage.value = pkg
        _tweaks.value = NexgtCatalog.build64Tweaks(pkg).map { fresh ->
            val old = _tweaks.value.find { it.id == fresh.id }
            if (old != null) fresh.copy(enabled = old.enabled, isFavorite = old.isFavorite) else fresh
        }
    }

    fun addGame(game: GameAppItem) {
        if (_games.value.none { it.packageName == game.packageName }) {
            _games.value = _games.value + game.copy(isAdded = true)
        }
    }

    fun setRenderScale(scale: Int) {
        _renderScale.value = scale
        val factor = scale / 100.0
        val pkg = _targetGamePackage.value
        viewModelScope.launch {
            ShizukuManager.runCommand("cmd game set --mode performance --downscale $factor $pkg")
        }
    }

    fun toggleSmartEngine(id: String) {
        _smartEngine.value = _smartEngine.value.map {
            if (it.id == id) it.copy(enabled = !it.enabled) else it
        }
    }

    fun toggleFpsModule(id: String) {
        val current = _fps120Modules.value.find { it.id == id } ?: return
        val next = !current.enabled
        _fps120Modules.value = _fps120Modules.value.map {
            if (it.id == id) it.copy(enabled = next) else it
        }
        val pkg = _targetGamePackage.value
        val cmd = (if (next) current.commandTemplate else current.resetCommandTemplate).replace("{pkg}", pkg)
        viewModelScope.launch {
            ShizukuManager.runCommand(cmd)
        }
    }

    fun unlock120FpsExtremeOneTap() {
        val pkg = _targetGamePackage.value
        _fps120Modules.value = _fps120Modules.value.map { it.copy(enabled = true) }
        _turboActive.value = true
        viewModelScope.launch {
            _fps120Modules.value.forEach { mod ->
                ShizukuManager.runCommand(mod.commandTemplate.replace("{pkg}", pkg))
            }
            _statusBanner.value = "120 FPS Extremo aplicado em $pkg!"
        }
    }

    fun restoreFactoryFps() {
        val pkg = _targetGamePackage.value
        _fps120Modules.value = _fps120Modules.value.map { it.copy(enabled = false) }
        _nativeShowFps.value = false
        viewModelScope.launch {
            ShizukuManager.runCommand("cmd thermalservice reset")
            ShizukuManager.runCommand("cmd game reset $pkg")
            ShizukuManager.runCommand("cmd power set-fixed-performance-mode-enabled false")
            ShizukuManager.runCommand("setprop debug.sf.showfps 0")
            _statusBanner.value = "Padrão de fábrica FPS restaurado."
        }
    }

    fun toggleNativeShowFps() {
        val next = !_nativeShowFps.value
        _nativeShowFps.value = next
        viewModelScope.launch {
            ShizukuManager.runCommand("setprop debug.sf.showfps ${if (next) 1 else 0}")
        }
    }

    fun toggleTweak(id: String) {
        val target = _tweaks.value.find { it.id == id } ?: return
        val next = !target.enabled
        _tweaks.value = _tweaks.value.map {
            if (it.id == id) it.copy(enabled = next) else it
        }
        val cmd = if (next) target.enableCmd else target.disableCmd
        viewModelScope.launch {
            ShizukuManager.runCommand(cmd)
        }
    }

    fun toggleFavorite(id: String) {
        _tweaks.value = _tweaks.value.map {
            if (it.id == id) it.copy(isFavorite = !it.isFavorite) else it
        }
    }

    fun runCustomTerminalCommand(cmd: String) {
        if (cmd.isBlank()) return
        viewModelScope.launch {
            ShizukuManager.runCommand(cmd.trim())
        }
    }

    fun toggleFreezeApp(pkg: String) {
        val target = _installedApps.value.find { it.packageName == pkg } ?: return
        val nextFrozen = !target.isFrozen
        _installedApps.value = _installedApps.value.map {
            if (it.packageName == pkg) it.copy(isFrozen = nextFrozen) else it
        }
        viewModelScope.launch {
            val cmd = if (nextFrozen) {
                "pm disable-user --user 0 $pkg && appops set $pkg RUN_IN_BACKGROUND ignore"
            } else {
                "pm enable $pkg && appops set $pkg RUN_IN_BACKGROUND allow"
            }
            ShizukuManager.runCommand(cmd)
        }
    }

    fun applySettingsEditor(table: String, key: String, value: String) {
        if (key.isBlank() || value.isBlank()) return
        viewModelScope.launch {
            ShizukuManager.runCommand("settings put $table ${key.trim()} ${value.trim()}")
        }
    }

    fun toggleBankMode() {
        val next = !_bankMode.value
        _bankMode.value = next
        repo.setBankModeEnabled(next)
        if (next) {
            _floatingPanelActive.value = false
            _fpsOverlayActive.value = false
            stopOverlayService()
            _statusBanner.value = "Modo Banco ativo: overlays suspensos."
        }
    }

    fun restoreAllTweaks() {
        _turboActive.value = false
        _tweaks.value = _tweaks.value.map { it.copy(enabled = false) }
        _fps120Modules.value = _fps120Modules.value.map { it.copy(enabled = false) }
        _nativeShowFps.value = false
        viewModelScope.launch {
            ShizukuManager.runCommand("cmd thermalservice reset && cmd power set-fixed-performance-mode-enabled false && cmd game reset ${_targetGamePackage.value}")
            _statusBanner.value = "Todas as configurações foram restauradas."
        }
    }

    fun uninstallWithCleanup() {
        viewModelScope.launch {
            restoreAllTweaks()
            runCatching {
                val app = getApplication<Application>()
                val intent = Intent(Intent.ACTION_DELETE).apply {
                    data = Uri.parse("package:${app.packageName}")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                app.startActivity(intent)
            }
        }
    }

    fun toggleFpsOverlay(): Boolean {
        val app = getApplication<Application>()
        if (!Settings.canDrawOverlays(app)) {
            requestOverlayPermission()
            return false
        }
        _fpsOverlayActive.value = !_fpsOverlayActive.value
        syncOverlayService()
        return true
    }

    fun toggleFloatingPanelOverlay(): Boolean {
        val app = getApplication<Application>()
        if (!Settings.canDrawOverlays(app)) {
            requestOverlayPermission()
            return false
        }
        _floatingPanelActive.value = !_floatingPanelActive.value
        syncOverlayService()
        return true
    }

    private fun requestOverlayPermission() {
        runCatching {
            val app = getApplication<Application>()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${app.packageName}")
            ).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            app.startActivity(intent)
            _statusBanner.value = "Conceda permissão de sobreposição (SYSTEM_ALERT_WINDOW)."
        }
    }

    private fun syncOverlayService() {
        runCatching {
            val app = getApplication<Application>()
            if (!_fpsOverlayActive.value && !_floatingPanelActive.value) {
                stopOverlayService()
                return
            }
            val intent = Intent(app, FloatingOverlayService::class.java).apply {
                putExtra(FloatingOverlayService.EXTRA_SHOW_BUBBLE, _floatingPanelActive.value)
                putExtra(FloatingOverlayService.EXTRA_SHOW_FPS, _fpsOverlayActive.value)
                putExtra(FloatingOverlayService.EXTRA_ACCENT_HEX, _selectedTheme.value.accentHex)
                putExtra(FloatingOverlayService.EXTRA_TARGET_PKG, _targetGamePackage.value)
            }
            app.startForegroundService(intent)
        }
    }

    private fun stopOverlayService() {
        runCatching {
            val app = getApplication<Application>()
            app.stopService(Intent(app, FloatingOverlayService::class.java))
        }
    }
}
