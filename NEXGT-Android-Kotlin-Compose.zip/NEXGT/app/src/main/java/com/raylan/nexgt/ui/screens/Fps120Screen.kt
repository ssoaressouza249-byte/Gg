package com.raylan.nexgt.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raylan.nexgt.data.Fps120Module
import com.raylan.nexgt.data.GameAppItem
import com.raylan.nexgt.ui.components.CommandInfoDialog
import com.raylan.nexgt.ui.components.NexgtCard
import com.raylan.nexgt.ui.components.NexgtSwitch
import com.raylan.nexgt.ui.theme.LocalNexgtPalette

@Composable
fun Fps120Screen(
    games: List<GameAppItem>,
    targetPackage: String,
    modules: List<Fps120Module>,
    fpsOverlayActive: Boolean,
    nativeShowFps: Boolean,
    onSelectTargetGame: (String) -> Unit,
    onUnlockExtremeOneTap: () -> Unit,
    onToggleModule: (String) -> Unit,
    onToggleFpsOverlay: () -> Unit,
    onToggleNativeShowFps: () -> Unit,
    onRestoreFactoryFps: () -> Unit
) {
    val palette = LocalNexgtPalette.current
    var infoModule by remember { mutableStateOf<Fps120Module?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "Destravar 100–120 FPS Reais",
                color = palette.textPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                text = "Selecione o jogo alvo para aplicar os comandos Shizuku diretamente no pacote:",
                color = palette.textSecondary,
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(8.dp))

            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(games, key = { it.packageName }) { game ->
                    val selected = game.packageName == targetPackage
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (selected) palette.accent else palette.cardSurface)
                            .border(
                                1.dp,
                                if (selected) palette.accent else palette.accentBorder.copy(alpha = 0.35f),
                                RoundedCornerShape(12.dp)
                            )
                            .clickable { onSelectTargetGame(game.packageName) }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Text(
                            text = game.name,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Botão principal 1 Toque
        item {
            Button(
                onClick = onUnlockExtremeOneTap,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = palette.accent,
                    contentColor = Color.White
                )
            ) {
                Icon(Icons.Default.Bolt, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "DESTRAVAR 120 FPS EXTREMO (1 TOQUE)",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp
                )
            }
        }

        // Overlay FPS em tempo real + debug.sf.showfps
        item {
            NexgtCard(highlighted = fpsOverlayActive || nativeShowFps) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "OVERLAY FPS EM TEMPO REAL",
                            color = palette.textPrimary,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = "Contador flutuante Choreographer sobre o jogo (SYSTEM_ALERT_WINDOW)",
                            color = palette.textSecondary,
                            fontSize = 11.sp
                        )
                    }
                    Button(
                        onClick = onToggleFpsOverlay,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (fpsOverlayActive) palette.success else palette.accent,
                            contentColor = Color.White
                        )
                    ) {
                        Icon(Icons.Default.Speed, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (fpsOverlayActive) "ATIVO" else "ATIVAR", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Contador Nativo SurfaceFlinger",
                            color = palette.textPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "setprop debug.sf.showfps 1",
                            color = palette.accent,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    NexgtSwitch(
                        checked = nativeShowFps,
                        onCheckedChange = { onToggleNativeShowFps() }
                    )
                }
            }
        }

        // 8 módulos individuais 120 FPS
        items(modules, key = { it.id }) { mod ->
            NexgtCard(highlighted = mod.enabled) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = mod.title,
                            color = palette.textPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Text(
                            text = mod.description,
                            color = palette.textSecondary,
                            fontSize = 11.sp
                        )
                    }
                    IconButton(onClick = { infoModule = mod }) {
                        Icon(Icons.Default.Info, contentDescription = "Ver comando", tint = palette.accent)
                    }
                    NexgtSwitch(
                        checked = mod.enabled,
                        onCheckedChange = { onToggleModule(mod.id) }
                    )
                }
            }
        }

        // Restaurar Padrão de Fábrica FPS
        item {
            OutlinedButton(
                onClick = onRestoreFactoryFps,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(Icons.Default.Restore, contentDescription = null, tint = palette.textPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Restaurar Padrão de Fábrica FPS",
                    color = palette.textPrimary,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    infoModule?.let { mod ->
        CommandInfoDialog(
            title = mod.title,
            command = mod.commandTemplate.replace("{pkg}", targetPackage),
            description = mod.description,
            onDismiss = { infoModule = null }
        )
    }
}
