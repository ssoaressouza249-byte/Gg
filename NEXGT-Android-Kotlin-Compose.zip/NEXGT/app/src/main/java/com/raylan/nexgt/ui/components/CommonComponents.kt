package com.raylan.nexgt.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raylan.nexgt.data.NavTab
import com.raylan.nexgt.ui.theme.LocalNexgtPalette

@Composable
fun NexgtCard(
    modifier: Modifier = Modifier,
    highlighted: Boolean = false,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val palette = LocalNexgtPalette.current
    val shape = RoundedCornerShape(18.dp)
    val borderColor = if (highlighted) palette.accent else palette.accentBorder.copy(alpha = 0.35f)
    val bgBrush = if (highlighted) {
        Brush.verticalGradient(
            listOf(palette.accent.copy(alpha = 0.22f), palette.cardSurface)
        )
    } else {
        Brush.verticalGradient(
            listOf(Color(0xFF171721), palette.cardSurface)
        )
    }

    val baseModifier = modifier
        .clip(shape)
        .background(bgBrush)
        .border(width = if (highlighted) 1.5.dp else 1.dp, color = borderColor, shape = shape)
        .let { if (onClick != null) it.clickable { onClick() } else it }
        .padding(14.dp)

    Column(modifier = baseModifier, content = content)
}

@Composable
fun NexgtSwitch(
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    val palette = LocalNexgtPalette.current
    Switch(
        checked = checked,
        onCheckedChange = onCheckedChange,
        colors = SwitchDefaults.colors(
            checkedThumbColor = Color.White,
            checkedTrackColor = palette.accent,
            uncheckedThumbColor = palette.textSecondary,
            uncheckedTrackColor = Color(0xFF1F1F2B),
            uncheckedBorderColor = palette.accentBorder.copy(alpha = 0.4f)
        )
    )
}

@Composable
fun MasterTurboStickyBar(
    turboActive: Boolean,
    activeCount: Int,
    onToggle: () -> Unit
) {
    val palette = LocalNexgtPalette.current
    val brush = if (turboActive) {
        Brush.horizontalGradient(
            listOf(palette.accent, palette.accent.copy(alpha = 0.72f))
        )
    } else {
        Brush.horizontalGradient(
            listOf(Color(0xFF181822), Color(0xFF12121A))
        )
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(palette.oledBackground.copy(alpha = 0.96f))
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Button(
            onClick = onToggle,
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .border(
                    width = 1.5.dp,
                    color = palette.accent,
                    shape = RoundedCornerShape(16.dp)
                )
                .background(brush, RoundedCornerShape(16.dp)),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.Transparent,
                contentColor = Color.White
            )
        ) {
            Icon(
                imageVector = Icons.Default.Bolt,
                contentDescription = null,
                tint = if (turboActive) Color.White else palette.accent,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (turboActive) "DESATIVAR TURBINA JOGOS" else "ATIVAR TURBINA JOGOS",
                fontWeight = FontWeight.ExtraBold,
                fontSize = 13.sp,
                fontFamily = FontFamily.Default,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.width(10.dp))
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.42f))
                    .padding(horizontal = 9.dp, vertical = 3.dp)
            ) {
                Text(
                    text = "$activeCount ativas",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun NexgtBottomNavBar(
    currentTab: NavTab,
    onSelectTab: (NavTab) -> Unit
) {
    val palette = LocalNexgtPalette.current

    NavigationBar(
        containerColor = Color(0xFF0E0E13),
        contentColor = palette.textPrimary,
        tonalElevation = 0.dp
    ) {
        NavTab.entries.forEach { tab ->
            val selected = currentTab == tab
            val icon = when (tab) {
                NavTab.HOME -> Icons.Default.Home
                NavTab.GAMES -> Icons.Default.SportsEsports
                NavTab.FPS_120 -> Icons.Default.Speed
                NavTab.TWEAKS -> Icons.Default.Tune
                NavTab.AX_MANAGE -> Icons.Default.Extension
                NavTab.TOOLS -> Icons.Default.Build
            }
            NavigationBarItem(
                selected = selected,
                onClick = { onSelectTab(tab) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = tab.label,
                        modifier = Modifier.size(20.dp)
                    )
                },
                label = {
                    Text(
                        text = tab.label,
                        fontSize = 9.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Clip
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = palette.accent,
                    selectedTextColor = palette.accent,
                    indicatorColor = palette.accentSoft,
                    unselectedIconColor = palette.textSecondary,
                    unselectedTextColor = palette.textSecondary
                )
            )
        }
    }
}

@Composable
fun CommandInfoDialog(
    title: String,
    command: String,
    description: String,
    onDismiss: () -> Unit
) {
    val palette = LocalNexgtPalette.current
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = palette.cardSurfaceSolid,
        title = {
            Text(
                text = title,
                color = palette.textPrimary,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Default
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = description,
                    color = palette.textSecondary,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Default
                )
                Text(
                    text = "Comando Shell Shizuku (UID 2000):",
                    color = palette.accent,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF09090D))
                        .border(1.dp, palette.accentBorder.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        text = command,
                        color = Color(0xFFE4E4E7),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Fechar", color = palette.accent, fontWeight = FontWeight.Bold)
            }
        }
    )
}
