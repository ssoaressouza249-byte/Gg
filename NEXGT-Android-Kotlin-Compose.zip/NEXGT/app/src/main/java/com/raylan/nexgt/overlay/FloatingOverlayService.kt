package com.raylan.nexgt.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.raylan.nexgt.shizuku.ShizukuManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class FloatingOverlayService : Service() {

    companion object {
        const val CHANNEL_ID = "nexgt_overlay_channel"
        const val NOTIFICATION_ID = 2026
        const val EXTRA_SHOW_BUBBLE = "show_bubble"
        const val EXTRA_SHOW_FPS = "show_fps"
        const val EXTRA_ACCENT_HEX = "accent_hex"
        const val EXTRA_TARGET_PKG = "target_pkg"
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var windowManager: WindowManager? = null

    private var bubbleView: View? = null
    private var panelView: View? = null
    private var fpsView: TextView? = null

    private var accentColor: Int = Color.parseColor("#A855F7")
    private var targetPkg: String = "com.dts.freefireth"
    private var isPanelOpen = false

    private var frameCount = 0
    private var lastFrameTimeNs = 0L
    private var fpsCallbackRunning = false

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!fpsCallbackRunning) return
            if (lastFrameTimeNs == 0L) {
                lastFrameTimeNs = frameTimeNanos
            }
            frameCount++
            val elapsedNs = frameTimeNanos - lastFrameTimeNs
            if (elapsedNs >= 500_000_000L) {
                val fps = ((frameCount * 1_000_000_000.0) / elapsedNs).toInt().coerceIn(1, 240)
                fpsView?.text = "$fps FPS"
                frameCount = 0
                lastFrameTimeNs = frameTimeNanos
            }
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        runCatching {
            val showBubble = intent?.getBooleanExtra(EXTRA_SHOW_BUBBLE, false) ?: false
            val showFps = intent?.getBooleanExtra(EXTRA_SHOW_FPS, false) ?: false
            val hex = intent?.getStringExtra(EXTRA_ACCENT_HEX) ?: "#A855F7"
            targetPkg = intent?.getStringExtra(EXTRA_TARGET_PKG) ?: targetPkg
            accentColor = runCatching { Color.parseColor(hex) }.getOrDefault(Color.parseColor("#A855F7"))

            if (showBubble) showGojoBubble() else removeBubbleAndPanel()
            if (showFps) showFpsMeter() else removeFpsMeter()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        removeBubbleAndPanel()
        removeFpsMeter()
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun overlayLayoutType(): Int =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

    private fun showGojoBubble() {
        removeBubbleAndPanel()
        val wm = windowManager ?: return
        val sizePx = (58 * resources.displayMetrics.density).toInt()
        val params = WindowManager.LayoutParams(
            sizePx,
            sizePx,
            overlayLayoutType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 260
        }

        val view = GojoBubbleView(this, accentColor)
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var moved = false

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (kotlin.math.abs(dx) > 8 || kotlin.math.abs(dy) > 8) moved = true
                    params.x = startX + dx
                    params.y = startY + dy
                    runCatching { wm.updateViewLayout(view, params) }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) toggleMiniPanel()
                    true
                }
                else -> false
            }
        }

        runCatching {
            wm.addView(view, params)
            bubbleView = view
        }
    }

    private fun toggleMiniPanel() {
        val wm = windowManager ?: return
        if (isPanelOpen && panelView != null) {
            runCatching { wm.removeView(panelView) }
            panelView = null
            isPanelOpen = false
            return
        }

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 32, 36, 32)
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E60A0A0C"))
                cornerRadius = 42f
                setStroke(3, accentColor)
            }
        }

        val title = TextView(this).apply {
            text = "FF Boost • Painel Flutuante"
            setTextColor(Color.WHITE)
            textSize = 14f
            setPadding(0, 0, 0, 18)
        }
        container.addView(title)

        fun addQuickAction(label: String, cmd: String) {
            val btn = Button(this).apply {
                text = label
                setTextColor(Color.WHITE)
                textSize = 12f
                isAllCaps = false
                background = GradientDrawable().apply {
                    setColor(Color.argb(60, Color.red(accentColor), Color.green(accentColor), Color.blue(accentColor)))
                    cornerRadius = 24f
                    setStroke(2, accentColor)
                }
                setOnClickListener {
                    serviceScope.launch {
                        ShizukuManager.runCommand(cmd)
                    }
                }
            }
            val lp = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 14 }
            container.addView(btn, lp)
        }

        addQuickAction("Turbina Jogos", "cmd game mode performance $targetPkg && cmd thermalservice override-status 0")
        addQuickAction("Destravar 120 FPS", "cmd game set --mode performance --fps 120 $targetPkg && settings put system peak_refresh_rate 120.0")
        addQuickAction("Limpar RAM", "pm trim-caches 999G && am kill-all")
        addQuickAction("Congelar 2º Plano", "dumpsys deviceidle force-idle && cmd netpolicy set restrict-background true")

        val closeBtn = Button(this).apply {
            text = "Fechar Painel"
            setTextColor(Color.LTGRAY)
            textSize = 11f
            setBackgroundColor(Color.TRANSPARENT)
            setOnClickListener { toggleMiniPanel() }
        }
        container.addView(closeBtn)

        val params = WindowManager.LayoutParams(
            (250 * resources.displayMetrics.density).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayLayoutType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        runCatching {
            wm.addView(container, params)
            panelView = container
            isPanelOpen = true
        }
    }

    private fun showFpsMeter() {
        removeFpsMeter()
        val wm = windowManager ?: return
        val tv = TextView(this).apply {
            text = "120 FPS"
            setTextColor(Color.WHITE)
            textSize = 13f
            setPadding(24, 12, 24, 12)
            typeface = android.graphics.Typeface.MONOSPACE
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#CC0A0A0C"))
                cornerRadius = 28f
                setStroke(3, accentColor)
            }
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayLayoutType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 28
            y = 84
        }

        runCatching {
            wm.addView(tv, params)
            fpsView = tv
            fpsCallbackRunning = true
            frameCount = 0
            lastFrameTimeNs = 0L
            Choreographer.getInstance().postFrameCallback(frameCallback)
        }
    }

    private fun removeBubbleAndPanel() {
        val wm = windowManager ?: return
        bubbleView?.let { runCatching { wm.removeView(it) } }
        panelView?.let { runCatching { wm.removeView(it) } }
        bubbleView = null
        panelView = null
        isPanelOpen = false
    }

    private fun removeFpsMeter() {
        fpsCallbackRunning = false
        Choreographer.getInstance().removeFrameCallback(frameCallback)
        val wm = windowManager ?: return
        fpsView?.let { runCatching { wm.removeView(it) } }
        fpsView = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "NEXGT / FF Boost Overlay",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("FF Boost Ativo")
            .setContentText("Painel flutuante e monitor FPS em execução")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()
}

private class GojoBubbleView(
    context: Context,
    private val accentColor: Int
) : View(context) {

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E60A0A0C")
        style = Paint.Style.FILL
    }
    private val auraPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = accentColor
        style = Paint.Style.STROKE
        strokeWidth = 5f
    }
    private val hairPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F4F4F8")
        style = Paint.Style.FILL
    }
    private val maskPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#111118")
        style = Paint.Style.FILL
    }
    private val eyePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = accentColor
        style = Paint.Style.FILL
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val r = (minOf(width, height) / 2f) - 4f

        canvas.drawCircle(cx, cy, r, bgPaint)
        canvas.drawCircle(cx, cy, r - 2f, auraPaint)

        // Cabelo branco espetado estilizado
        val hairPath = Path().apply {
            moveTo(cx - r * 0.45f, cy - r * 0.05f)
            lineTo(cx - r * 0.55f, cy - r * 0.45f)
            lineTo(cx - r * 0.25f, cy - r * 0.35f)
            lineTo(cx - r * 0.1f, cy - r * 0.72f)
            lineTo(cx + r * 0.12f, cy - r * 0.42f)
            lineTo(cx + r * 0.38f, cy - r * 0.65f)
            lineTo(cx + r * 0.48f, cy - r * 0.12f)
            close()
        }
        canvas.drawPath(hairPath, hairPaint)

        // Venda escura com brilho de energia amaldiçoada
        canvas.drawRoundRect(
            cx - r * 0.44f,
            cy - r * 0.06f,
            cx + r * 0.44f,
            cy + r * 0.24f,
            10f,
            10f,
            maskPaint
        )
        canvas.drawCircle(cx - r * 0.16f, cy + r * 0.09f, r * 0.08f, eyePaint)
        canvas.drawCircle(cx + r * 0.16f, cy + r * 0.09f, r * 0.08f, eyePaint)
    }
}
