package com.raylan.nexgt

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import com.raylan.nexgt.data.NavTab
import com.raylan.nexgt.data.NexgtViewModel
import com.raylan.nexgt.security.SecurityGuard
import com.raylan.nexgt.security.TamperBlockedScreen
import com.raylan.nexgt.shizuku.ShizukuManager
import com.raylan.nexgt.ui.components.MasterTurboStickyBar
import com.raylan.nexgt.ui.components.NexgtBottomNavBar
import com.raylan.nexgt.ui.screens.AxManageScreen
import com.raylan.nexgt.ui.screens.Fps120Screen
import com.raylan.nexgt.ui.screens.GamesScreen
import com.raylan.nexgt.ui.screens.HomeScreen
import com.raylan.nexgt.ui.screens.ToolsScreen
import com.raylan.nexgt.ui.screens.TweaksScreen
import com.raylan.nexgt.ui.theme.LocalNexgtPalette
import com.raylan.nexgt.ui.theme.NexgtTheme

class MainActivity : ComponentActivity() {
    private val viewModel: NexgtViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val integrity = SecurityGuard.verify(this)

        setContent {
            if (!integrity.isValid) {
                TamperBlockedScreen(report = integrity)
            } else {
                val selectedTheme by viewModel.selectedTheme.collectAsState()
                NexgtTheme(selectedTheme = selectedTheme) {
                    NexgtMainScaffold(viewModel = viewModel)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        runCatching {
            ShizukuManager.refreshState()
            viewModel.refreshHardware()
            viewModel.refreshInstalledApps()
        }
    }
}

@Composable
private fun NexgtMainScaffold(viewModel: NexgtViewModel) {
    val palette = LocalNexgtPalette.current
    var currentTab by remember { mutableStateOf(NavTab.HOME) }
    val snackbarHostState = remember { SnackbarHostState() }

    val selectedTheme by viewModel.selectedTheme.collectAsState()
    val shizukuState by viewModel.shizukuState.collectAsState()
    val shizukuUid by viewModel.shizukuUid.collectAsState()
    val shizukuVersion by viewModel.shizukuVersion.collectAsState()
    val activeCount by viewModel.activeFunctionCount.collectAsState()
    val hardware by viewModel.hardwareInfo.collectAsState()
    val activeProfile by viewModel.activeProfile.collectAsState()
    val turboActive by viewModel.turboActive.collectAsState()
    val games by viewModel.games.collectAsState()
    val installedApps by viewModel.installedApps.collectAsState()
    val targetPackage by viewModel.targetGamePackage.collectAsState()
    val smartEngine by viewModel.smartEngine.collectAsState()
    val renderScale by viewModel.renderScale.collectAsState()
    val fps120Modules by viewModel.fps120Modules.collectAsState()
    val axManageModules by viewModel.axManageModules.collectAsState()
    val tweaks by viewModel.tweaks.collectAsState()
    val fpsOverlayActive by viewModel.fpsOverlayActive.collectAsState()
    val nativeShowFps by viewModel.nativeShowFps.collectAsState()
    val floatingPanelActive by viewModel.floatingPanelActive.collectAsState()
    val bankMode by viewModel.bankMode.collectAsState()
    val logs by viewModel.logs.collectAsState()
    val banner by viewModel.statusBanner.collectAsState()

    LaunchedEffect(banner) {
        val msg = banner ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(msg)
        viewModel.clearBanner()
    }

    Scaffold(
        containerColor = palette.oledBackground,
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        bottomBar = {
            Column(modifier = Modifier.fillMaxWidth()) {
                MasterTurboStickyBar(
                    turboActive = turboActive,
                    activeCount = activeCount,
                    onToggle = { viewModel.toggleMasterTurbo() }
                )
                NexgtBottomNavBar(
                    currentTab = currentTab,
                    onSelectTab = { currentTab = it }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(palette.oledBackground)
                .padding(innerPadding)
        ) {
            when (currentTab) {
                NavTab.HOME -> HomeScreen(
                    shizukuState = shizukuState,
                    activeCount = activeCount,
                    hardware = hardware,
                    activeProfile = activeProfile,
                    favorites = tweaks.filter { it.isFavorite },
                    onConnectShizuku = { viewModel.connectShizuku() },
                    onSelectProfile = { viewModel.selectProfile(it) },
                    onToggleTweak = { viewModel.toggleTweak(it) },
                    onNavigateTab = { currentTab = it }
                )

                NavTab.GAMES -> GamesScreen(
                    games = games,
                    installedApps = installedApps,
                    targetPackage = targetPackage,
                    smartEngine = smartEngine,
                    renderScale = renderScale,
                    onSelectGame = { viewModel.selectTargetGame(it) },
                    onAddGame = { viewModel.addGame(it) },
                    onToggleSmartFeature = { viewModel.toggleSmartEngine(it) },
                    onSelectRenderScale = { viewModel.setRenderScale(it) }
                )

                NavTab.FPS_120 -> Fps120Screen(
                    games = games,
                    targetPackage = targetPackage,
                    modules = fps120Modules,
                    fpsOverlayActive = fpsOverlayActive,
                    nativeShowFps = nativeShowFps,
                    onSelectTargetGame = { viewModel.selectTargetGame(it) },
                    onUnlockExtremeOneTap = { viewModel.unlock120FpsExtremeOneTap() },
                    onToggleModule = { viewModel.toggleFpsModule(it) },
                    onToggleFpsOverlay = { viewModel.toggleFpsOverlay() },
                    onToggleNativeShowFps = { viewModel.toggleNativeShowFps() },
                    onRestoreFactoryFps = { viewModel.restoreFactoryFps() }
                )

                NavTab.TWEAKS -> TweaksScreen(
                    tweaks = tweaks,
                    onToggleTweak = { viewModel.toggleTweak(it) },
                    onToggleCategory = { cat, enable -> viewModel.toggleCategoryTweaks(cat, enable) }
                )

                NavTab.AX_MANAGE -> AxManageScreen(
                    modules = axManageModules,
                    targetPackage = targetPackage,
                    onToggleModule = { viewModel.toggleAxManageModule(it) },
                    onToggleAll = { enable -> viewModel.toggleAllAxManageModules(enable) }
                )

                NavTab.TOOLS -> ToolsScreen(
                    selectedTheme = selectedTheme,
                    shizukuState = shizukuState,
                    shizukuUid = shizukuUid,
                    shizukuVersion = shizukuVersion,
                    floatingPanelActive = floatingPanelActive,
                    bankMode = bankMode,
                    activeTweaks = tweaks.filter { it.enabled },
                    installedApps = installedApps,
                    logs = logs,
                    onSelectTheme = { viewModel.selectTheme(it) },
                    onToggleFloatingPanel = { viewModel.toggleFloatingPanelOverlay() },
                    onConnectShizuku = { viewModel.connectShizuku() },
                    onRunTerminalCommand = { viewModel.runCustomTerminalCommand(it) },
                    onToggleFreezeApp = { viewModel.toggleFreezeApp(it) },
                    onUnfreezeAllApps = { viewModel.unfreezeAllUserApps() },
                    onApplySetting = { table, key, value -> viewModel.applySettingsEditor(table, key, value) },
                    onToggleBankMode = { viewModel.toggleBankMode() },
                    onRestoreAll = { viewModel.restoreAllTweaks() },
                    onUninstallWithCleanup = { viewModel.uninstallWithCleanup() }
                )
            }
        }
    }
}
