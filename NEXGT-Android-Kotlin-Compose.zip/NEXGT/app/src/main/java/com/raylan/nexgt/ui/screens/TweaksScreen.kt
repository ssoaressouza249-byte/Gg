package com.raylan.nexgt.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raylan.nexgt.data.TweakCategory
import com.raylan.nexgt.data.TweakItem
import com.raylan.nexgt.ui.components.CommandInfoDialog
import com.raylan.nexgt.ui.components.NexgtCard
import com.raylan.nexgt.ui.components.NexgtSwitch
import com.raylan.nexgt.ui.theme.LocalNexgtPalette

@Composable
fun TweaksScreen(
    tweaks: List<TweakItem>,
    onToggleTweak: (String) -> Unit,
    onToggleCategory: (TweakCategory, Boolean) -> Unit
) {
    val palette = LocalNexgtPalette.current
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(TweakCategory.PERFORMANCE) }
    var infoTweak by remember { mutableStateOf<TweakItem?>(null) }

    val filteredTweaks = remember(tweaks, searchQuery, selectedCategory) {
        if (searchQuery.isNotBlank()) {
            val q = searchQuery.trim().lowercase()
            tweaks.filter {
                it.title.lowercase().contains(q) ||
                    it.summary.lowercase().contains(q) ||
                    it.enableCmd.lowercase().contains(q)
            }
        } else {
            tweaks.filter { it.category == selectedCategory }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Buscar entre ${tweaks.size} funções reais...", color = palette.textSecondary) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = palette.accent) },
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = palette.accent,
                    unfocusedBorderColor = palette.accentBorder.copy(alpha = 0.4f),
                    focusedTextColor = palette.textPrimary,
                    unfocusedTextColor = palette.textPrimary,
                    focusedContainerColor = palette.cardSurface,
                    unfocusedContainerColor = palette.cardSurface
                )
            )
            Spacer(modifier = Modifier.height(10.dp))

            // 5 sub-abas em pílulas
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(TweakCategory.entries) { cat ->
                    val active = selectedCategory == cat && searchQuery.isBlank()
                    val count = tweaks.count { it.category == cat }
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(if (active) palette.accent else palette.cardSurface)
                            .border(
                                1.dp,
                                if (active) palette.accent else palette.accentBorder.copy(alpha = 0.35f),
                                CircleShape
                            )
                            .clickable {
                                searchQuery = ""
                                selectedCategory = cat
                            }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = "${cat.label} ($count)",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            if (searchQuery.isBlank()) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { onToggleCategory(selectedCategory, true) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.accent)
                    ) {
                        Text("Ativar ${selectedCategory.label}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = { onToggleCategory(selectedCategory, false) },
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text("Desativar", color = palette.textPrimary, fontSize = 11.sp)
                    }
                }
            }
        }

        // Grade 2 colunas com 94 funções reais
        items(filteredTweaks.chunked(2)) { rowItems ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                rowItems.forEach { item ->
                    NexgtCard(
                        modifier = Modifier.weight(1f),
                        highlighted = item.enabled
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = item.title,
                                color = palette.textPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { infoTweak = item },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Info,
                                    contentDescription = "Ver comando",
                                    tint = palette.accent,
                                    modifier = Modifier.size(17.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = item.summary,
                            color = palette.textSecondary,
                            fontSize = 10.sp,
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (item.enabled) "ATIVO" else "INATIVO",
                                color = if (item.enabled) palette.accent else palette.textSecondary,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Monospace
                            )
                            NexgtSwitch(
                                checked = item.enabled,
                                onCheckedChange = { onToggleTweak(item.id) }
                            )
                        }
                    }
                }
                if (rowItems.size == 1) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    infoTweak?.let { item ->
        CommandInfoDialog(
            title = item.title,
            command = item.enableCmd,
            description = item.summary,
            onDismiss = { infoTweak = null }
        )
    }
}
