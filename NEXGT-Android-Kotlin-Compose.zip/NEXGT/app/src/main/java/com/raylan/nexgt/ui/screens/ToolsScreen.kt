package com.raylan.nexgt.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.raylan.nexgt.data.GameAppItem
import com.raylan.nexgt.data.TweakItem
import com.raylan.nexgt.shizuku.ShizukuConnectionState
import com.raylan.nexgt.shizuku.ShizukuLogEntry
import com.raylan.nexgt.ui.components.NexgtCard
import com.raylan.nexgt.ui.components.NexgtSwitch
import com.raylan.nexgt.ui.theme.LocalNexgtPalette
import com.raylan.nexgt.ui.theme.NexgtColorTheme
import com.raylan.nexgt.ui.theme.NexgtThemes

@Composable
fun ToolsScreen(
    selectedTheme: NexgtColorTheme,
    shizukuState: ShizukuConnectionState,
    shizukuUid: Int?,
    shizukuVersion: Int?,
    floatingPanelActive: Boolean,
    bankMode: Boolean,
    activeTweaks: List<TweakItem>,
    installedApps: List<GameAppItem>,
    logs: List<ShizukuLogEntry>,
    onSelectTheme: (NexgtColorTheme) -> Unit,
    onToggleFloatingPanel: () -> Unit,
    onConnectShizuku: () -> Unit,
    onRunTerminalCommand: (String) -> Unit,
    onToggleFreezeApp: (String) -> Unit,
    onApplySetting: (String, String, String) -> Unit,
    onToggleBankMode: () -> Unit,
    onRestoreAll: () -> Unit,
    onUninstallWithCleanup: () -> Unit
) {
    val palette = LocalNexgtPalette.current

    var terminalCmd by remember { mutableStateOf("id && getprop ro.build.version.release") }
    var settingsTable by remember { mutableStateOf("system") }
    var settingKey by remember { mutableStateOf("peak_refresh_rate") }
    var settingValue by remember { mutableStateOf("120.0") }

    // Teste de Toque (Hz)
    var touchHz by remember { mutableIntStateOf(0) }
    var lastEventMs by remember { mutableLongStateOf(0L) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Botão destaque Painel Flutuante (Overlay)
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Button(
                onClick = onToggleFloatingPanel,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (floatingPanelActive) palette.success else palette.accent,
                    contentColor = Color.White
                )
            ) {
                Icon(Icons.Default.Layers, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (floatingPanelActive) {
                        "PAINEL FLUTUANTE ATIVO (TOQUE P/ DESATIVAR)"
                    } else {
                        "ATIVAR PAINEL FLUTUANTE (OVERLAY)"
                    },
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 12.sp
                )
            }
        }

        // Cor do App (10 temas)
        item {
            NexgtCard {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Palette, contentDescription = null, tint = palette.accent)
                    Text("Cor do App (10 Temas)", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
                Spacer(modifier = Modifier.height(10.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(NexgtThemes.all, key = { it.id }) { theme ->
                        val active = theme.id == selectedTheme.id
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.clickable { onSelectTheme(theme) }
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(theme.accent)
                                    .border(
                                        width = if (active) 3.dp else 1.dp,
                                        color = if (active) Color.White else Color.White.copy(alpha = 0.2f),
                                        shape = CircleShape
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (active) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = theme.name.substringBefore(" "),
                                color = if (active) palette.textPrimary else palette.textSecondary,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }

        // Central Shizuku + Terminal de Teste
        item {
            NexgtCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Terminal, contentDescription = null, tint = palette.accent)
                        Text("Central Shizuku", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Text(
                        text = "UID: ${shizukuUid ?: "--"} | API: ${shizukuVersion ?: "--"}",
                        color = palette.accent,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Estado: ${shizukuState.name}",
                    color = palette.textSecondary,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = terminalCmd,
                    onValueChange = { terminalCmd = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Comando Shell Rápido") },
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onRunTerminalCommand(terminalCmd) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.accent)
                    ) {
                        Text("Executar", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(
                        onClick = onConnectShizuku,
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Autorizar", color = palette.textPrimary)
                    }
                }
            }
        }

        // Teste de Toque (Hz)
        item {
            NexgtCard {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.TouchApp, contentDescription = null, tint = palette.accent)
                        Text("Teste de Toque (Hz)", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Text(
                        text = "$touchHz Hz",
                        color = palette.accent,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(92.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF0E0E15))
                        .border(1.dp, palette.accentBorder, RoundedCornerShape(14.dp))
                        .pointerInput(Unit) {
                            awaitEachGesture {
                                while (true) {
                                    awaitPointerEvent()
                                    val now = System.currentTimeMillis()
                                    if (lastEventMs > 0L) {
                                        val delta = (now - lastEventMs).coerceAtLeast(1L)
                                        touchHz = (1000L / delta).toInt().coerceIn(30, 1000)
                                    }
                                    lastEventMs = now
                                }
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Deslize o dedo aqui para medir a taxa de amostragem do toque",
                        color = palette.textSecondary,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Editor de Configurações (system / secure / global)
        item {
            NexgtCard {
                Text("Editor de Configurações (Settings)", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("system", "secure", "global").forEach { table ->
                        val active = settingsTable == table
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (active) palette.accent else Color(0xFF1A1A24))
                                .clickable { settingsTable = table }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(table, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = settingKey,
                    onValueChange = { settingKey = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Chave (key)") },
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = settingValue,
                    onValueChange = { settingValue = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Valor (value)") },
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = { onApplySetting(settingsTable, settingKey, settingValue) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = palette.accent)
                ) {
                    Text("Aplicar settings put $settingsTable", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Congelador de Apps
        item {
            NexgtCard {
                Text("Congelador de Apps (pm disable-user / appops)", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(8.dp))
                if (installedApps.isEmpty()) {
                    Text("Nenhum app de usuário listado no momento.", color = palette.textSecondary, fontSize = 12.sp)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        installedApps.take(8).forEach { app ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(app.name, color = palette.textPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Text(app.packageName, color = palette.textSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                }
                                NexgtSwitch(
                                    checked = app.isFrozen,
                                    onCheckedChange = { onToggleFreezeApp(app.packageName) }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Funções Ativas + Modo Banco + Restaurar + Desinstalar
        item {
            NexgtCard {
                Text("Funções Ativas (${activeTweaks.size})", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                if (activeTweaks.isEmpty()) {
                    Text("Nenhum ajuste da aba Ajustes ativo agora.", color = palette.textSecondary, fontSize = 12.sp)
                } else {
                    activeTweaks.take(6).forEach { tweak ->
                        Text("• ${tweak.title}", color = palette.accent, fontSize = 12.sp)
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = palette.accent)
                        Column {
                            Text("Modo Banco", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Suspende overlays ao abrir apps bancários", color = palette.textSecondary, fontSize = 11.sp)
                        }
                    }
                    NexgtSwitch(checked = bankMode, onCheckedChange = { onToggleBankMode() })
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = onRestoreAll, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.Restore, contentDescription = null, tint = palette.textPrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Restaurar Tudo", color = palette.textPrimary, fontSize = 11.sp)
                    }
                    Button(
                        onClick = onUninstallWithCleanup,
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = palette.danger)
                    ) {
                        Icon(Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Desinstalar", fontSize = 11.sp)
                    }
                }
            }
        }

        // Registro de Atividades (Log real)
        item {
            NexgtCard {
                Text("Registro de Atividades (Shell Real)", color = palette.textPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(8.dp))
                if (logs.isEmpty()) {
                    Text("Nenhuma saída registrada ainda.", color = palette.textSecondary, fontSize = 12.sp)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        logs.take(15).forEach { log ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF09090D))
                                    .padding(8.dp)
                            ) {
                                Text(
                                    text = "[${log.timestamp}] ${log.command}",
                                    color = if (log.success) palette.success else palette.danger,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                                Text(
                                    text = log.output,
                                    color = palette.textSecondary,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }
        }

        // Créditos oficiais
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 14.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "NEXGT / FF Boost • Criado por Raylan",
                    color = palette.textSecondary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
